# Freedom – Take Back Control (Addiction Freedom)

Local-first PWA, die beim Aufhören unterstützt (Snus, Rauchen, Alkohol, Zucker u. a.).
**Datenschutz:** Alle Daten bleiben im Browser (localStorage). Kein Konto, kein Tracking, keine Analytics.

## MVP-Funktionen
Dashboard · sekundengenauer, kalenderkorrekter Timer (nur Startzeitstempel gespeichert, läuft auch nach Neustart) · Onboarding mit Kategorie · SOS-Modus (Soforthilfe, Atemübung 4-4-6, 5-Min-Craving-Timer, eigene Gründe) · Ersparnis (heute/Woche/Monat/gesamt/Jahr) · Meilensteine mit Animation · Gesundheitsbereich mit Quelleneinordnung · Rückfall ohne Schuldzuweisung (Gesamttage + längste Serie bleiben) · JSON-Backup/Import · Offline (PWA).

## Start
```bash
npm install
npm run dev        # Entwicklung
npm test           # Unit-Tests der Kernlogik
npm run build      # Produktion (dist/), PWA inklusive
```

## Architektur
`src/core` reine Logik (Timer, Ersparnis, Meilensteine, Store) · `src/app` UI und Inhalte.
Neue Kategorien: Eintrag in `src/app/content.ts` (`HABITS`, `UNIT`).

## Roadmap
Tagebuch & Rückfallanalyse, Wenn-Dann-Pläne, i18n (EN), Dexie/IndexedDB, Capacitor (native Benachrichtigungen), Playwright-E2E.
Wichtig: Gesundheitstexte vor Veröffentlichung gegen aktuelle Quellen (WHO, DKFZ, CDC, Cochrane) prüfen.

## Auf GitHub veröffentlichen
```bash
git init && git add . && git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<DEIN-NAME>/addiction-freedom.git
git push -u origin main
```
Dann im Repo: **Settings → Pages → Source: GitHub Actions**. Nach dem ersten Lauf ist die App unter `https://<DEIN-NAME>.github.io/addiction-freedom/` erreichbar und auf dem Smartphone installierbar ("Zum Home-Bildschirm").
