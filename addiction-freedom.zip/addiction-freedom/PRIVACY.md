# Datenschutz
Die App speichert Eingaben ausschließlich lokal auf deinem Gerät. Es werden keine Daten an Server übertragen. Backups exportierst du selbst.
