export const HABITS = ['Snus / Nikotinbeutel', 'Rauchen', 'Alkohol', 'Zucker', 'Energy-Drinks', 'Social Media', 'Glücksspiel', 'Andere Gewohnheit'];
export const UNIT: Record<string, string> = { 'Snus / Nikotinbeutel': 'Dose', Rauchen: 'Packung', Alkohol: 'Getränk', Zucker: 'Einkauf', 'Energy-Drinks': 'Dose', 'Social Media': 'Stunde', Glücksspiel: 'Einsatz', 'Andere Gewohnheit': 'Einheit' };
export const TIPS = ['Trink ein Glas kaltes Wasser.', 'Kaue Kaugummi.', 'Geh 5 Minuten spazieren.', 'Putz dir die Zähne.', 'Atme tief durch – nutze die Atemübung.', 'Verlasse den Ort, wenn er ein Auslöser ist.', 'Erinnere dich, warum du aufgehört hast.', 'Beschäftige Mund und Hände: Zahnstocher, Nüsse, Strohhalm, Knetball.'];
export const CRAVING_MSGS = ['Das Verlangen ist eine Welle – sie steigt, erreicht den Gipfel und fällt wieder.', 'Die stärkste Phase dauert meist nur wenige Minuten.', 'Trink jetzt ein Glas Wasser.', 'Steh auf und wechsle den Raum.', 'Atme 4 Sekunden ein, 6 Sekunden aus.', 'Du hast schon bewiesen, dass du durchhältst.', 'Gleich geschafft – bleib dran.'];
export const DAILY = ['Jeder Tag ohne ist ein Sieg.', 'Du entscheidest, nicht das Verlangen.', 'Kleine Schritte zählen.', 'Ein Rückschlag löscht nicht deinen Fortschritt.', 'Heute für dein zukünftiges Ich.'];
export const HEALTH = [
  { h: 24, t: 'Nach ca. 1 Tag: Der Körper beginnt, sich von akuten Nikotinwirkungen zu erholen; Entzugsbeschwerden wie Unruhe und Reizbarkeit können einsetzen.', s: 'Erfahrung/Entzug – individuell' },
  { h: 72, t: 'Nach 2–3 Tagen: Entzugssymptome sind meist am stärksten (Verlangen, Gereiztheit, Schlafprobleme).', s: 'Belegt für Rauchstopp (u. a. CDC, DKFZ); für Nikotinbeutel vermutlich übertragbar' },
  { h: 720, t: 'Nach Wochen: Körperliche Entzugssymptome klingen bei vielen deutlich ab; Gewohnheiten und Auslöser bleiben die Hauptherausforderung.', s: 'Belegt für Rauchstopp; individuell verschieden' },
  { h: 8760, t: 'Nach Monaten bis Jahren: Langfristig sinken Gesundheitsrisiken, z. B. für Herz-Kreislauf-Erkrankungen – belegt für den Rauchstopp (WHO, DKFZ).', s: 'Belegt für Rauchstopp; für Nikotinbeutel weniger Daten' },
];
