import { useEffect, useRef, useState } from 'react';
import { breakdown, wholeDays } from '../core/timer';
import { savings } from '../core/savings';
import { label, milestoneState } from '../core/milestones';
import { exportJson, importJson, relapse, set, useStore, type State } from '../core/store';
import { CRAVING_MSGS, DAILY, HABITS, HEALTH, TIPS, UNIT } from './content';

const eur = (n: number) => n.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' });
function useNow(ms = 1000) { const [n, setN] = useState(Date.now()); useEffect(() => { const i = setInterval(() => setN(Date.now()), ms); return () => clearInterval(i); }, [ms]); return n; }
type View = 'home' | 'sos' | 'health' | 'settings';

export default function App() {
  const s = useStore(); const [v, setV] = useState<View>('home');
  if (!s) return <Onboarding />;
  return (<div className="wrap">
    {v === 'home' && <Dashboard s={s} go={setV} />}
    {v === 'sos' && <Sos s={s} back={() => setV('home')} />}
    {v === 'health' && <Health s={s} back={() => setV('home')} />}
    {v === 'settings' && <Settings s={s} back={() => setV('home')} />}
    {v !== 'sos' && <button className="sos" onClick={() => setV('sos')}>🆘 SOS – Ich habe Verlangen</button>}
  </div>);
}

function Onboarding() {
  const [habit, setHabit] = useState(HABITS[0]); const [date, setDate] = useState(() => new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 16));
  const [price, setPrice] = useState('6'); const [units, setUnits] = useState('1'); const [reasons, setReasons] = useState('Ich will wieder die Kontrolle haben.\nIch will unabhängig sein.');
  const ts = new Date(date).getTime(); const ok = !isNaN(ts) && ts <= Date.now();
  return (<div className="wrap"><h1>Freedom – Take Back Control</h1><p className="mut">Alle Daten bleiben auf deinem Gerät. Kein Konto, kein Tracking.</p>
    <div className="card"><h2>Was willst du hinter dir lassen?</h2><select value={habit} onChange={e => setHabit(e.target.value)}>{HABITS.map(h => <option key={h}>{h}</option>)}</select>
      <h2>Aufhördatum &amp; Uhrzeit</h2><input type="datetime-local" value={date} max={date.slice(0, 16)} onChange={e => setDate(e.target.value)} />
      <h2>Preis pro {UNIT[habit]} (€)</h2><input inputMode="decimal" value={price} onChange={e => setPrice(e.target.value)} />
      <h2>Verbrauch pro Tag ({UNIT[habit]})</h2><input inputMode="decimal" value={units} onChange={e => setUnits(e.target.value)} />
      <h2>Meine Gründe (einer pro Zeile)</h2><textarea rows={4} value={reasons} onChange={e => setReasons(e.target.value)} />
      <button disabled={!ok} onClick={() => set({ habit, start: ts, pricePerUnit: parseFloat(price.replace(',', '.')) || 0, unitsPerDay: parseFloat(units.replace(',', '.')) || 0, reasons: reasons.split('\n').map(r => r.trim()).filter(Boolean), attempts: [] })}>Los geht's</button>
      {!ok && <p className="mut">Das Datum darf nicht in der Zukunft liegen.</p>}</div></div>);
}

function Dashboard({ s, go }: { s: State; go: (v: View) => void }) {
  const now = useNow(); const b = breakdown(s.start, now); const sv = savings(s.start, now, s); const m = milestoneState(s.start, now);
  const cleanTotal = s.attempts.reduce((a, t) => a + wholeDays(t.start, t.end), 0) + wholeDays(s.start, now);
  const longest = Math.max(wholeDays(s.start, now), ...s.attempts.map(t => wholeDays(t.start, t.end)));
  const [seen, setSeen] = useState(() => Number(localStorage.getItem('af:seen:' + s.start) || 0));
  useEffect(() => { if (seen === 0 && m.reached.length > 0 && localStorage.getItem('af:seen:' + s.start) === null) ack(); });
  const fresh = m.reached.length > seen ? m.reached[m.reached.length - 1] : null;
  const ack = () => { localStorage.setItem('af:seen:' + s.start, String(m.reached.length)); setSeen(m.reached.length); };
  const units: [number, string][] = [[b.years, 'Jahre'], [b.months, 'Monate'], [b.weeks, 'Wochen'], [b.days, 'Tage'], [b.hours, 'Std'], [b.minutes, 'Min'], [b.seconds, 'Sek']];
  const g = new Date().getHours() < 12 ? 'Guten Morgen' : new Date().getHours() < 18 ? 'Guten Tag' : 'Guten Abend';
  return (<>
    {fresh && seen > 0 && <div className="pop" onClick={ack}><div><div style={{ fontSize: 64 }}>🏆</div><h1>{label(fresh.hours)} geschafft!</h1><p className="mut">Tippe zum Fortfahren</p></div></div>}
    <h1>{g} 👋</h1><div className="card"><h2>Dein Leben ohne {s.habit.split(' /')[0]}</h2>
      <div className="grid">{units.map(([n, l]) => <div className="u" key={l}><b>{String(n).padStart(l === 'Std' || l === 'Min' || l === 'Sek' ? 2 : 1, '0')}</b><span>{l}</span></div>)}</div></div>
    <div className="card"><h2>Fortschritt</h2><p className="big">{cleanTotal} freie Tage gesamt</p><p className="mut">Längste Serie: {longest} Tage · Versuche: {s.attempts.length + 1}</p></div>
    <div className="card"><h2>Gespartes Geld</h2><p className="big">{eur(sv.total)}</p>
      <p className="mut">Heute {eur(sv.today)} · Woche {eur(sv.week)} · Monat {eur(sv.month)} · Jahr (Hochrechnung) {eur(sv.year)}</p></div>
    <div className="card"><h2>Nächster Meilenstein</h2>{m.next ? <><p><b>{label(m.next.hours)}</b></p><div className="bar"><i style={{ width: `${Math.round(m.progress * 100)}%` }} /></div></> : <p>Alle Meilensteine erreicht! 🎉</p>}</div>
    <div className="card"><h2>Heute</h2><p>{DAILY[new Date().getDate() % DAILY.length]}</p></div>
    <button className="g" onClick={() => go('health')}>Gesundheitsfortschritt</button><button className="g" onClick={() => go('settings')}>Einstellungen &amp; Backup</button>
  </>);
}

function Sos({ s, back }: { s: State; back: () => void }) {
  const [tab, setTab] = useState<'tips' | 'breath' | 'timer'>('tips'); const [ri, setRi] = useState(0);
  useEffect(() => { const i = setInterval(() => setRi(r => r + 1), 6000); return () => clearInterval(i); }, []);
  return (<><button className="g" onClick={back}>← Zurück</button><h1>Du schaffst das.</h1>
    {s.reasons.length > 0 && <div className="card"><h2>Dein Grund</h2><p className="big">{s.reasons[ri % s.reasons.length]}</p></div>}
    <div style={{ display: 'flex', gap: 8 }}>{(['tips', 'breath', 'timer'] as const).map(t => <button key={t} className={tab === t ? '' : 'g'} onClick={() => setTab(t)}>{{ tips: 'Soforthilfe', breath: 'Atmen', timer: '5-Min-Timer' }[t]}</button>)}</div>
    {tab === 'tips' && <div className="card">{TIPS.map(t => <p key={t}>✓ {t}</p>)}</div>}
    {tab === 'breath' && <Breath />}{tab === 'timer' && <Craving done={back} />}</>);
}

const PHASES = [{ n: 'Einatmen', s: 4, sc: 1.4 }, { n: 'Halten', s: 4, sc: 1.4 }, { n: 'Ausatmen', s: 6, sc: 1 }];
function Breath() {
  const [i, setI] = useState(0);
  useEffect(() => { const t = setTimeout(() => setI(x => (x + 1) % 3), PHASES[i].s * 1000); return () => clearTimeout(t); }, [i]);
  const p = PHASES[i];
  return <div className="card" style={{ textAlign: 'center' }}><div className="orb" style={{ transform: `scale(${p.sc})`, ['--d' as string]: `${p.s}s` }}>{p.n}</div><p className="mut">4 s ein · 4 s halten · 6 s aus</p></div>;
}

function Craving({ done }: { done: () => void }) {
  const total = 300; const end = useRef<number | null>(null); const [left, setLeft] = useState(total);
  const [run, setRun] = useState(false);
  useEffect(() => { if (!run) return; const i = setInterval(() => setLeft(Math.max(0, Math.ceil((end.current! - Date.now()) / 1000))), 250); return () => clearInterval(i); }, [run]);
  const msg = CRAVING_MSGS[Math.min(CRAVING_MSGS.length - 1, Math.floor(((total - left) / total) * CRAVING_MSGS.length))];
  return (<div className="card" style={{ textAlign: 'center' }}>
    <p className="big">{String(Math.floor(left / 60)).padStart(2, '0')}:{String(left % 60).padStart(2, '0')}</p>
    {left === 0 ? <><p className="big">🎉 Geschafft! Das Verlangen ist vorbei.</p><button onClick={done}>Zurück zum Dashboard</button></>
      : <><p>{run ? msg : 'Starte den Timer und überstehe die Welle.'}</p>{!run && <button onClick={() => { end.current = Date.now() + total * 1000; setRun(true); }}>Timer starten</button>}</>}</div>);
}

function Health({ s, back }: { s: State; back: () => void }) {
  const hrs = (Date.now() - s.start) / 3600e3;
  return (<><button className="g" onClick={back}>← Zurück</button><h1>Gesundheitsfortschritt</h1>
    <p className="mut">Hinweis: Die gut belegten Daten stammen überwiegend aus der Raucherforschung. Das ist keine medizinische Beratung.</p>
    {HEALTH.map(x => <div className="card" key={x.h} style={{ opacity: hrs >= x.h ? 1 : .5 }}><p>{hrs >= x.h ? '✅' : '🔒'} {x.t}</p><p className="mut">Einordnung: {x.s}</p></div>)}</>);
}

function Settings({ s, back }: { s: State; back: () => void }) {
  const [msg, setMsg] = useState('');
  const dl = () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([exportJson(s)], { type: 'application/json' })); a.download = 'freedom-backup.json'; a.click(); };
  return (<><button className="g" onClick={back}>← Zurück</button><h1>Einstellungen</h1>
    <div className="card"><h2>Rückfall</h2><p className="mut">Ein Rückfall ist kein Versagen. Deine bisherigen Tage bleiben gespeichert, nur die aktuelle Serie startet neu.</p>
      <button className="g" onClick={() => { if (confirm('Serie neu starten? Deine Gesamttage bleiben erhalten.')) { relapse(s); back(); } }}>Serie neu starten</button></div>
    <div className="card"><h2>Backup</h2><button onClick={dl}>Backup exportieren</button>
      <input type="file" accept="application/json" onChange={async e => { try { importJson(await e.target.files![0].text()); setMsg('Import erfolgreich.'); } catch { setMsg('Ungültige Datei.'); } }} /><p className="mut">{msg}</p></div>
    <div className="card"><h2>Daten löschen</h2><button className="g" onClick={() => { if (confirm('Alle Daten unwiderruflich löschen?')) set(null); }}>Alles löschen</button></div></>);
}
