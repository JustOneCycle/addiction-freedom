import { describe, expect, it } from 'vitest';
import { breakdown, wholeDays } from './timer';
import { savings } from './savings';
import { milestoneState } from './milestones';
const t0 = new Date(2025, 0, 1, 8, 0, 0).getTime();
describe('timer', () => {
  it('breaks down calendar-correct', () => {
    const b = breakdown(t0, new Date(2025, 2, 11, 16, 32, 14).getTime());
    expect(b).toMatchObject({ months: 2, weeks: 1, days: 3, hours: 8, minutes: 32, seconds: 14 });
  });
  it('never negative', () => expect(wholeDays(t0, t0 - 1000)).toBe(0));
});
describe('savings', () => {
  it('total and year', () => {
    const s = savings(t0, t0 + 10 * 864e5, { pricePerUnit: 5, unitsPerDay: 1 });
    expect(s.total).toBeCloseTo(50); expect(s.year).toBe(1825);
  });
});
describe('milestones', () => {
  it('finds next', () => {
    const m = milestoneState(t0, t0 + 25 * 3600e3);
    expect(m.reached.length).toBe(2); expect(m.next?.id).toBe('3d');
  });
});
