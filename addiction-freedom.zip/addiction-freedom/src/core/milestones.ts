const H = 3600e3;
export const MILESTONES = [
  { id: '1h', hours: 1 }, { id: '24h', hours: 24 }, { id: '3d', hours: 72 }, { id: '7d', hours: 168 },
  { id: '14d', hours: 336 }, { id: '30d', hours: 720 }, { id: '60d', hours: 1440 }, { id: '90d', hours: 2160 },
  { id: '180d', hours: 4320 }, { id: '365d', hours: 8760 },
];
export const label = (h: number) => (h < 24 ? `${h} Stunde` : `${h / 24} Tage`);
export function milestoneState(start: number, now: number) {
  const hrs = Math.max(0, now - start) / H;
  const reached = MILESTONES.filter(m => hrs >= m.hours);
  const next = MILESTONES.find(m => hrs < m.hours) ?? null;
  const prev = reached.length ? reached[reached.length - 1].hours : 0;
  return { reached, next, progress: next ? (hrs - prev) / (next.hours - prev) : 1 };
}
