import { intervalToDuration } from 'date-fns';
/** Elapsed time is always derived from a stored timestamp, never counted by ticking. */
export function breakdown(start: number, now: number) {
  const d = intervalToDuration({ start, end: Math.max(now, start) });
  const days = d.days ?? 0;
  return { years: d.years ?? 0, months: d.months ?? 0, weeks: Math.floor(days / 7), days: days % 7,
    hours: d.hours ?? 0, minutes: d.minutes ?? 0, seconds: d.seconds ?? 0 };
}
export const DAY = 864e5;
export const wholeDays = (start: number, now: number) => Math.floor(Math.max(0, now - start) / DAY);
