import { useSyncExternalStore } from 'react';
export interface Attempt { start: number; end: number }
export interface State {
  habit: string; start: number; pricePerUnit: number; unitsPerDay: number;
  reasons: string[]; attempts: Attempt[];
}
const KEY = 'af:v1';
let state: State | null = load();
const subs = new Set<() => void>();
function load(): State | null { try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch { return null; } }
export function set(s: State | null) {
  state = s;
  try { s ? localStorage.setItem(KEY, JSON.stringify(s)) : localStorage.removeItem(KEY); } catch { /* storage full/blocked */ }
  subs.forEach(f => f());
}
export const useStore = () => useSyncExternalStore(f => (subs.add(f), () => subs.delete(f)), () => state);
export const relapse = (s: State, now = Date.now()) => set({ ...s, attempts: [...s.attempts, { start: s.start, end: now }], start: now });
export const exportJson = (s: State) => JSON.stringify({ app: 'addiction-freedom', version: 1, data: s }, null, 2);
export function importJson(txt: string) {
  const o = JSON.parse(txt);
  if (o?.app !== 'addiction-freedom' || typeof o.data?.start !== 'number') throw new Error('invalid');
  set(o.data);
}
if (typeof navigator !== 'undefined') navigator.storage?.persist?.();
