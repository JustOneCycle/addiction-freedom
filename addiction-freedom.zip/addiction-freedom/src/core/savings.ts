import { DAY } from './timer';
export interface Cost { pricePerUnit: number; unitsPerDay: number }
export const costPerDay = (c: Cost) => Math.max(0, c.pricePerUnit) * Math.max(0, c.unitsPerDay);
export function savings(start: number, now: number, c: Cost) {
  const per = costPerDay(c), el = Math.max(0, now - start);
  const midnight = new Date(now); midnight.setHours(0, 0, 0, 0);
  const f = (ms: number) => (Math.min(el, ms) / DAY) * per;
  return { today: f(now - midnight.getTime()), week: f(7 * DAY), month: f(30 * DAY), total: f(el), year: per * 365 };
}
